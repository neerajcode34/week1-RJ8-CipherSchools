import React from "react";
import AllUsersList from "./components/AllUsersList";
//import Test from "./Test";
const App = () => {
  return (
    <>
      <section>
        <AllUsersList/>
        
      </section>
    </>  
  );
};

export default App;


///     div
//      /  \
//    Test  Test

///      section
//         /  \
//      Test   Test
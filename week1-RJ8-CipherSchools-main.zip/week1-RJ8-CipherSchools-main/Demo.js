function demoFunction() {
    return [1, 2];
}

let [abc, def] = demoFunction();
console.log(`ABC: is ${abc} and DEF is ${def}`);